cmake_minimum_required(VERSION 3.21)
project(airplay-windows VERSION 0.5.0 LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

if(MSVC)
    add_compile_options(/W4 /permissive- /utf-8)
    add_definitions(-D_WIN32_WINNT=0x0A00 -DWIN32_LEAN_AND_MEAN -DNOMINMAX
                    -D_CRT_SECURE_NO_WARNINGS)
else()
    add_compile_options(-Wall -Wextra -Wpedantic)
endif()

# ---- libplist (required) ------------------------------------------------------
# UxPlay uses libplist to serialise the /info, ANNOUNCE and other RTSP bodies.
# We take the same dependency rather than writing a bplist00 encoder by hand.
# Try three lookup paths in order (vcpkg / Linux pkg-config / raw find_*).
set(LIBPLIST_TARGET "")

find_package(PkgConfig QUIET)
if(PkgConfig_FOUND)
    pkg_check_modules(LIBPLIST IMPORTED_TARGET libplist-2.0 QUIET)
    if(LIBPLIST_FOUND)
        set(LIBPLIST_TARGET PkgConfig::LIBPLIST)
    endif()
endif()

if(NOT LIBPLIST_TARGET)
    find_package(libplist CONFIG QUIET)
    foreach(_t libplist::libplist-2.0 libplist::libplist unofficial::libplist::libplist)
        if(TARGET ${_t})
            set(LIBPLIST_TARGET ${_t})
            break()
        endif()
    endforeach()
endif()

if(NOT LIBPLIST_TARGET)
    # vcpkg doesn't ship a CMake config for libplist on all platforms — fall
    # back to raw finders. With the vcpkg toolchain, CMAKE_PREFIX_PATH already
    # points at vcpkg_installed/<triplet>/{include,lib}, so these just work.
    find_path(LIBPLIST_INCLUDE_DIR plist/plist.h)
    find_library(LIBPLIST_LIBRARY NAMES plist-2.0 libplist-2.0 plist libplist)
    if(LIBPLIST_INCLUDE_DIR AND LIBPLIST_LIBRARY)
        message(STATUS "libplist: raw find — include=${LIBPLIST_INCLUDE_DIR} "
                       "lib=${LIBPLIST_LIBRARY}")
        add_library(airplay_libplist INTERFACE)
        target_include_directories(airplay_libplist INTERFACE "${LIBPLIST_INCLUDE_DIR}")
        target_link_libraries(airplay_libplist INTERFACE "${LIBPLIST_LIBRARY}")
        set(LIBPLIST_TARGET airplay_libplist)
    endif()
endif()

# ---- OpenSSL (required) -------------------------------------------------------
# Used for Ed25519 identity keys, X25519 ECDH, AES-CTR and SHA-512 during the
# AirPlay pair-setup / pair-verify handshake.
find_package(OpenSSL REQUIRED COMPONENTS Crypto)

# ---- FFmpeg (required for H.264 decoding) -------------------------------------
# Uses libavcodec to decode the clear H.264 NAL units the mirror stream
# produces after AES-CTR decrypt + AVCC→Annex-B conversion. libswscale is
# for YUV→RGB conversion when dumping debug frames to PPM.
set(FFMPEG_TARGETS "")
if(PkgConfig_FOUND)
    pkg_check_modules(AVCODEC  IMPORTED_TARGET libavcodec)
    pkg_check_modules(AVFORMAT IMPORTED_TARGET libavformat)
    pkg_check_modules(AVUTIL   IMPORTED_TARGET libavutil)
    pkg_check_modules(SWSCALE  IMPORTED_TARGET libswscale)
    if(AVCODEC_FOUND AND AVFORMAT_FOUND AND AVUTIL_FOUND AND SWSCALE_FOUND)
        set(FFMPEG_TARGETS PkgConfig::AVCODEC PkgConfig::AVFORMAT
                           PkgConfig::AVUTIL PkgConfig::SWSCALE)
    endif()
endif()
if(NOT FFMPEG_TARGETS)
    # vcpkg path (Windows): use its FindFFMPEG module.
    find_package(FFMPEG QUIET)
    if(FFMPEG_FOUND)
        set(FFMPEG_TARGETS ${FFMPEG_LIBRARIES})
        set(FFMPEG_INCLUDE_DIRS_OK "${FFMPEG_INCLUDE_DIRS}")
    endif()
endif()
if(NOT FFMPEG_TARGETS)
    message(FATAL_ERROR
        "FFmpeg (libavcodec + libavutil + libswscale) not found.\n"
        "  Windows: vcpkg.json already declares the dependency — rerun cmake "
        "with the vcpkg toolchain.\n"
        "  Linux:   apt install libavcodec-dev libswscale-dev")
endif()

# ---- SDL2 (required for the video renderer window) ----------------------------
# Used by video/VideoRenderer to create a real-time window displaying the
# decoded iPhone screen. On Windows we prefer the SDL2 CMake config that
# vcpkg ships — it carries proper debug/release variants. pkg-config's
# .pc files don't distinguish (vcpkg drops both debug and release into the
# same PKG_CONFIG_PATH), so a Release build can pick up SDL2d.lib by
# accident and the .exe ends up linked against the debug DLLs. Linux's
# pkg-config has only one variant per system, so it stays the primary
# search there.
set(SDL2_TARGET "")
if(NOT WIN32 AND PkgConfig_FOUND)
    pkg_check_modules(SDL2 IMPORTED_TARGET sdl2)
    if(SDL2_FOUND)
        set(SDL2_TARGET PkgConfig::SDL2)
    endif()
endif()
if(NOT SDL2_TARGET)
    find_package(SDL2 CONFIG QUIET)
    if(TARGET SDL2::SDL2)
        set(SDL2_TARGET SDL2::SDL2)
    elseif(TARGET SDL2::SDL2-static)
        set(SDL2_TARGET SDL2::SDL2-static)
    endif()
endif()
if(NOT SDL2_TARGET AND PkgConfig_FOUND)
    # Fallback: try pkg-config even on Windows if the CMake config
    # is missing for some reason.
    pkg_check_modules(SDL2 IMPORTED_TARGET sdl2)
    if(SDL2_FOUND)
        set(SDL2_TARGET PkgConfig::SDL2)
    endif()
endif()
if(NOT SDL2_TARGET)
    message(FATAL_ERROR
        "SDL2 not found.\n"
        "  Windows: rerun cmake with the vcpkg toolchain.\n"
        "  Linux:   apt install libsdl2-dev")
endif()

# ---- SDL2_ttf (required for the metadata text overlay) ------------------------
# Same debug/release trap as SDL2 above — prefer the vcpkg CMake config
# on Windows so MSVC links against SDL2_ttf.lib (release) and not
# SDL2_ttfd.lib (debug, the .pc-config-found-first failure mode).
set(SDL2_TTF_TARGET "")
if(NOT WIN32 AND PkgConfig_FOUND)
    pkg_check_modules(SDL2_TTF IMPORTED_TARGET SDL2_ttf)
    if(SDL2_TTF_FOUND)
        set(SDL2_TTF_TARGET PkgConfig::SDL2_TTF)
    endif()
endif()
if(NOT SDL2_TTF_TARGET)
    find_package(SDL2_ttf CONFIG QUIET)
    if(TARGET SDL2_ttf::SDL2_ttf)
        set(SDL2_TTF_TARGET SDL2_ttf::SDL2_ttf)
    elseif(TARGET SDL2_ttf::SDL2_ttf-static)
        set(SDL2_TTF_TARGET SDL2_ttf::SDL2_ttf-static)
    endif()
endif()
if(NOT SDL2_TTF_TARGET AND PkgConfig_FOUND)
    pkg_check_modules(SDL2_TTF IMPORTED_TARGET SDL2_ttf)
    if(SDL2_TTF_FOUND)
        set(SDL2_TTF_TARGET PkgConfig::SDL2_TTF)
    endif()
endif()
if(NOT SDL2_TTF_TARGET)
    message(FATAL_ERROR
        "SDL2_ttf not found.\n"
        "  Windows: rerun cmake with the vcpkg toolchain (already in vcpkg.json).\n"
        "  Linux:   apt install libsdl2-ttf-dev")
endif()

# ---- GStreamer (preferred HLS backend if available) ---------------------------
# We have two HLS backends:
#   - GStreamer (hls_player_gstreamer.cpp) — handles HLS live-edge buffering,
#     variant switching, HEVC mux gracefully.
#   - libavformat (hls_player.cpp) — single-file, no extra runtime dep, but
#     less robust on YouTube-style mlhls streams.
#
# USE_GSTREAMER_HLS = AUTO (default): pick GStreamer if pkg-config finds it,
# else fall back to libavformat. ON forces GStreamer (errors if not found),
# OFF forces libavformat. So a single `cmake build` directory does the right
# thing on a developer machine that has GStreamer installed.
set(USE_GSTREAMER_HLS "AUTO" CACHE STRING
    "HLS backend: AUTO (prefer GStreamer if found), ON (require it), OFF (libavformat)")
set_property(CACHE USE_GSTREAMER_HLS PROPERTY STRINGS AUTO ON OFF)
set(HLS_PLAYER_SRC src/video/hls_player.cpp)
set(_use_gst FALSE)
if(USE_GSTREAMER_HLS STREQUAL "ON")
    set(_use_gst TRUE)
elseif(USE_GSTREAMER_HLS STREQUAL "AUTO")
    set(_use_gst TRUE)         # tentative — checked below
endif()
if(_use_gst)
    if(NOT PkgConfig_FOUND)
        if(USE_GSTREAMER_HLS STREQUAL "ON")
            message(FATAL_ERROR "USE_GSTREAMER_HLS=ON requires pkg-config")
        endif()
        message(STATUS "HLS backend: pkg-config missing → falling back to libavformat")
        set(_use_gst FALSE)
    endif()
endif()
if(_use_gst)
    # Windows convenience: -DGSTREAMER_ROOT=... propagates into
    # PKG_CONFIG_PATH. Accepts either:
    #   - the install root:
    #       C:/Program Files/gstreamer/1.0/msvc_x86_64
    #   - the pkgconfig dir directly (which is already how pkg-config
    #     wants it):
    #       C:/Program Files/gstreamer/1.0/msvc_x86_64/lib/pkgconfig
    # Normalises backslashes to '/' for CMake consumption.
    if(GSTREAMER_ROOT)
        string(REPLACE "\\" "/" _gst_root "${GSTREAMER_ROOT}")
        # Accept any of: install root, .../lib, .../lib/pkgconfig, .../pkgconfig.
        # Probe each candidate in turn for gstreamer-1.0.pc.
        set(_gst_pkg_dir "")
        foreach(_cand
                "${_gst_root}"
                "${_gst_root}/pkgconfig"
                "${_gst_root}/lib/pkgconfig"
                "${_gst_root}/lib")
            if(EXISTS "${_cand}/gstreamer-1.0.pc")
                set(_gst_pkg_dir "${_cand}")
                break()
            endif()
        endforeach()
        if(_gst_pkg_dir)
            message(STATUS "GSTREAMER_ROOT=${GSTREAMER_ROOT}")
            message(STATUS "  → pkgconfig dir: ${_gst_pkg_dir}")
            if(WIN32)
                set(ENV{PKG_CONFIG_PATH}
                    "${_gst_pkg_dir};$ENV{PKG_CONFIG_PATH}")
            else()
                set(ENV{PKG_CONFIG_PATH}
                    "${_gst_pkg_dir}:$ENV{PKG_CONFIG_PATH}")
            endif()
        else()
            message(WARNING
                "GSTREAMER_ROOT=${GSTREAMER_ROOT}\n"
                "  gstreamer-1.0.pc not found under that path. Checked:\n"
                "    ${_gst_root}\n"
                "    ${_gst_root}/pkgconfig\n"
                "    ${_gst_root}/lib/pkgconfig\n"
                "    ${_gst_root}/lib\n"
                "  On Windows the development files live under:\n"
                "    C:/Program Files/gstreamer/1.0/msvc_x86_64/lib/pkgconfig\n"
                "  If gstreamer-1.0.pc is missing entirely, re-run the MSI\n"
                "  installer in Custom mode and enable the whole feature tree.")
        endif()
    endif()
    pkg_check_modules(GSTREAMER IMPORTED_TARGET
        gstreamer-1.0 gstreamer-app-1.0 gstreamer-video-1.0)
    if(NOT GSTREAMER_FOUND)
        if(USE_GSTREAMER_HLS STREQUAL "ON")
            message(FATAL_ERROR
                "USE_GSTREAMER_HLS=ON but gstreamer-1.0/gstreamer-app-1.0/gstreamer-video-1.0 not found.\n"
                "  Windows: install GStreamer MSVC x86_64 from\n"
                "           https://gstreamer.freedesktop.org/download/ and either\n"
                "             set PKG_CONFIG_PATH before cmake, or pass\n"
                "             -DGSTREAMER_ROOT=\"C:/Program Files/gstreamer/1.0/msvc_x86_64\"\n"
                "  Linux:   apt install libgstreamer1.0-dev libgstreamer-plugins-base1.0-dev\n"
                "                       libgstreamer-plugins-bad1.0-dev gstreamer1.0-libav\n"
                "                       gstreamer1.0-plugins-good gstreamer1.0-plugins-bad")
        endif()
        message(STATUS "HLS backend: GStreamer not found → using libavformat")
        set(_use_gst FALSE)
    else()
        message(STATUS "HLS backend: GStreamer (${GSTREAMER_VERSION})")
        set(HLS_PLAYER_SRC src/video/hls_player_gstreamer.cpp)
    endif()
endif()
if(NOT _use_gst)
    message(STATUS "HLS backend: libavformat "
                   "(force GStreamer with -DUSE_GSTREAMER_HLS=ON)")
endif()

# ---- Dear ImGui (in-app overlay UI) ------------------------------------------
# Pinned vendored copy of Dear ImGui + the SDL2 / SDLRenderer2 backends. We
# draw directly over the SDL renderer — zero IPC, zero frame copy, runs in
# the same thread/GPU context as the video texture. The overlay gives us a
# device sidebar, live stats, hotkeys config, recording HUD, etc., without
# a webview.
include(FetchContent)
FetchContent_Declare(
    imgui
    GIT_REPOSITORY https://github.com/ocornut/imgui.git
    GIT_TAG        v1.91.5
    GIT_SHALLOW    TRUE
)
FetchContent_MakeAvailable(imgui)

add_library(imgui STATIC
    ${imgui_SOURCE_DIR}/imgui.cpp
    ${imgui_SOURCE_DIR}/imgui_draw.cpp
    ${imgui_SOURCE_DIR}/imgui_tables.cpp
    ${imgui_SOURCE_DIR}/imgui_widgets.cpp
    ${imgui_SOURCE_DIR}/backends/imgui_impl_sdl2.cpp
    ${imgui_SOURCE_DIR}/backends/imgui_impl_sdlrenderer2.cpp
)
target_include_directories(imgui PUBLIC
    ${imgui_SOURCE_DIR}
    ${imgui_SOURCE_DIR}/backends)
target_link_libraries(imgui PUBLIC ${SDL2_TARGET})
if(MSVC)
    # Quiet the upstream warnings — we don't control imgui's source hygiene.
    target_compile_options(imgui PRIVATE /W0)
endif()

# ---- Sources ------------------------------------------------------------------
add_executable(airplay-windows
    src/main.cpp
    src/log.cpp
    src/settings.cpp
    src/platform/desktop_controls.cpp
    src/net/socket.cpp
    src/net/tcp_server.cpp
    src/mdns/mdns_service.cpp
    src/crypto/identity.cpp
    src/crypto/pair_verify.cpp
    src/crypto/fairplay.cpp
    src/crypto/mirror_decrypt.cpp
    src/airplay/airplay2_setup.cpp
    src/airplay/daap.cpp
    src/airplay/h264_nal.cpp
    src/airplay/h264_sps.cpp
    src/airplay/info_plist.cpp
    src/airplay/mirror_listener.cpp
    src/airplay/ntp_client.cpp
    src/airplay/rtsp_parser.cpp
    src/airplay/sdp.cpp
    src/airplay/dacp_remote.cpp
    src/airplay/server.cpp
    src/airplay/streams.cpp
    src/airplay/fcup.cpp
    src/airplay/hls_local_server.cpp
    src/airplay/hls_session.cpp
    src/airplay/reverse_channel.cpp
    src/airplay/routes.cpp
    src/video/h264_decoder.cpp
    src/video/gpu_video.cpp
    src/video/face_swap.cpp
    src/video/face_swap_process.cpp
    src/video/face_swap_gpu.cpp
    src/video/gpu_recording.cpp
    src/video/video_recorder.cpp
    ${HLS_PLAYER_SRC}
    src/video/video_renderer.cpp
    src/platform/firewall.cpp
    src/video/cover_art.cpp
    src/audio/audio_receiver.cpp
    src/audio/aac_decoder.cpp
    src/audio/audio_output.cpp
    src/usb/pair_record.cpp
    src/usb/usb_supervisor.cpp
)

target_include_directories(airplay-windows PRIVATE src)
target_link_libraries(airplay-windows PRIVATE OpenSSL::Crypto ${FFMPEG_TARGETS} ${SDL2_TARGET} ${SDL2_TTF_TARGET} imgui)
if(_use_gst AND GSTREAMER_FOUND)
    target_link_libraries(airplay-windows PRIVATE PkgConfig::GSTREAMER)
    target_compile_definitions(airplay-windows PRIVATE HAVE_GSTREAMER_HLS=1)
endif()
if(DEFINED FFMPEG_INCLUDE_DIRS_OK)
    target_include_directories(airplay-windows PRIVATE ${FFMPEG_INCLUDE_DIRS_OK})
endif()

# ---- FairPlay SAP blobs (swap-ready) ------------------------------------------
# By default we link the zero-filled stub. If the user drops a real blob
# file into third_party/ (conventionally named fairplay_blobs_real.cpp),
# we link that instead. See docs/FAIRPLAY.md.
if(EXISTS "${CMAKE_SOURCE_DIR}/third_party/fairplay_blobs_real.cpp")
    message(STATUS "FairPlay: using provisioned blob (fairplay_blobs_real.cpp)")
    target_sources(airplay-windows PRIVATE
        third_party/fairplay_blobs_real.cpp)
else()
    message(STATUS "FairPlay: using zero-filled STUB — iOS handshake will "
                   "fail at /fp-setup until a real blob is provided")
    target_sources(airplay-windows PRIVATE
        third_party/fairplay_blobs_stub.cpp)
endif()

# ---- playfair (level-B FairPlay decrypt, swap-ready) --------------------------
# If third_party/playfair/ exists (copied from UxPlay's lib/playfair/), compile
# and link its C files so fairplay_decrypt(ekey) can recover the AES stream key.
# Without it, decryption is disabled and we only log the encrypted NAL units.
if(EXISTS "${CMAKE_SOURCE_DIR}/third_party/playfair/playfair.c")
    message(STATUS "playfair: using provisioned decryption library")
    set(_playfair_srcs
        third_party/playfair/playfair.c
        third_party/playfair/hand_garble.c
        third_party/playfair/omg_hax.c
        third_party/playfair/modified_md5.c
        third_party/playfair/sap_hash.c)
    target_sources(airplay-windows PRIVATE ${_playfair_srcs})
    # UxPlay's source uses `#include "playfair/playfair.h"` from fairplay_playfair.c
    # and `#include "playfair.h"` from within playfair/*.c, so we expose both.
    target_include_directories(airplay-windows PRIVATE
        third_party
        third_party/playfair)
    target_compile_definitions(airplay-windows PRIVATE HAVE_PLAYFAIR=1)

    # Quiet down playfair's legacy-C warnings (intentional byte truncations,
    # unused-variable debug leftovers, a spurious C4701 in modified_md5.c).
    # We keep our own source compiled at /W4 to catch real issues.
    if(MSVC)
        set_source_files_properties(${_playfair_srcs} PROPERTIES
            COMPILE_FLAGS "/wd4100 /wd4101 /wd4189 /wd4244 /wd4305 /wd4701")
    else()
        set_source_files_properties(${_playfair_srcs} PROPERTIES
            COMPILE_FLAGS "-w")
    endif()
else()
    message(STATUS "playfair: not provisioned — fairplay_decrypt() will be a no-op")
endif()

if(LIBPLIST_TARGET)
    message(STATUS "libplist: linking via ${LIBPLIST_TARGET}")
    target_link_libraries(airplay-windows PRIVATE ${LIBPLIST_TARGET})
    target_compile_definitions(airplay-windows PRIVATE HAVE_LIBPLIST=1)
else()
    message(FATAL_ERROR
        "libplist not found. Required for the /info binary plist — iOS will "
        "reject the handshake without it.\n"
        "  Windows: re-run cmake with -DCMAKE_TOOLCHAIN_FILE=<vcpkg>/scripts/"
        "buildsystems/vcpkg.cmake (vcpkg.json declares the dep).\n"
        "  Linux:   apt install libplist-dev")
endif()

if(WIN32)
    # ws2_32: Winsock; iphlpapi: GetAdaptersAddresses; dnsapi: native mDNS;
    # dwmapi: DwmSetWindowAttribute for the Win11 Mica backdrop on the
    # VideoRenderer window.
    target_link_libraries(airplay-windows PRIVATE
        ws2_32 iphlpapi dnsapi dwmapi d3d11 dxgi
        setupapi shell32 ole32 oleaut32 windowsapp)   # USB, Lockdown lookup and firewall COM API

    # Released as a GUI app so no empty console window pops up when
    # launched from File Explorer. main() stays the entry point — the
    # /ENTRY override avoids having to add a WinMain stub.
    set_target_properties(airplay-windows PROPERTIES WIN32_EXECUTABLE TRUE)
    if(MSVC)
        set_source_files_properties(src/platform/desktop_controls.cpp PROPERTIES
            COMPILE_OPTIONS "/std:c++20")
        target_link_options(airplay-windows PRIVATE "/ENTRY:mainCRTStartup")
    endif()
endif()

# ---- Runtime DLL deployment (Windows) ----------------------------------------
option(ENABLE_CUDA_FACE_SWAP "Build the optional CUDA/D3D11 face-swap bridge" ON)
set(CUDA_DRIVER_SDK_ROOT "" CACHE PATH "NVIDIA CUDA Runtime redistributable used to build the driver bridge")
if(WIN32 AND ENABLE_CUDA_FACE_SWAP)
    if(CUDA_DRIVER_SDK_ROOT)
        if(NOT EXISTS "${CUDA_DRIVER_SDK_ROOT}/include/cudaD3D11.h" OR
           NOT EXISTS "${CUDA_DRIVER_SDK_ROOT}/lib/x64/cuda.lib")
            message(FATAL_ERROR "CUDA_DRIVER_SDK_ROOT must contain the NVIDIA CUDA Runtime redistributable (Windows x64)")
        endif()
        add_library(airplay-cuda-driver UNKNOWN IMPORTED)
        set_target_properties(airplay-cuda-driver PROPERTIES
            IMPORTED_LOCATION "${CUDA_DRIVER_SDK_ROOT}/lib/x64/cuda.lib"
            INTERFACE_INCLUDE_DIRECTORIES "${CUDA_DRIVER_SDK_ROOT}/include")
        set(airplay_cuda_driver airplay-cuda-driver)
    else()
        find_package(CUDAToolkit QUIET)
        if(TARGET CUDA::cuda_driver)
            set(airplay_cuda_driver CUDA::cuda_driver)
        endif()
    endif()
    if(airplay_cuda_driver)
        add_library(airplay-cuda-bridge SHARED src/video/cuda_d3d11_bridge.cpp)
        target_link_libraries(airplay-cuda-bridge PRIVATE ${airplay_cuda_driver} d3d11 dxgi)
        set_target_properties(airplay-cuda-bridge PROPERTIES
            RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/$<CONFIG>/face_swap/engine")
        add_dependencies(airplay-windows airplay-cuda-bridge)
    endif()
endif()
option(BUILD_GPU_TESTS "Build the D3D11 hardware integration test" OFF)
if(WIN32 AND BUILD_GPU_TESTS)
    add_executable(render-face-swap-settings tools/render_face_swap_settings.cpp)
    target_include_directories(render-face-swap-settings PRIVATE src)
    target_link_libraries(render-face-swap-settings PRIVATE imgui ${SDL2_TARGET})
    if(TARGET airplay-cuda-bridge)
        add_executable(test-gpu-face-interop tools/test_gpu_face_interop.cpp src/video/face_swap_gpu.cpp
            src/video/face_swap.cpp src/video/face_swap_process.cpp src/net/socket.cpp src/log.cpp)
        target_include_directories(test-gpu-face-interop PRIVATE src ${FFMPEG_INCLUDE_DIRS_OK})
        target_link_libraries(test-gpu-face-interop PRIVATE ${FFMPEG_TARGETS} ${airplay_cuda_driver} d3d11 dxgi ws2_32 iphlpapi)
        add_dependencies(test-gpu-face-interop airplay-cuda-bridge)
    endif()
    add_executable(test-face-swap tools/test_face_swap.cpp src/video/face_swap.cpp src/video/face_swap_process.cpp src/video/face_swap_gpu.cpp
        src/net/socket.cpp src/log.cpp)
    target_include_directories(test-face-swap PRIVATE src ${FFMPEG_INCLUDE_DIRS_OK})
    target_link_libraries(test-face-swap PRIVATE ${FFMPEG_TARGETS} ws2_32 iphlpapi d3d11 dxgi)
    add_executable(test-gpu-video tools/test_gpu_video.cpp src/video/gpu_video.cpp
        src/video/h264_decoder.cpp src/video/gpu_recording.cpp
        src/video/video_recorder.cpp src/log.cpp)
    target_include_directories(test-gpu-video PRIVATE src ${FFMPEG_INCLUDE_DIRS_OK})
    target_compile_definitions(test-gpu-video PRIVATE SDL_MAIN_HANDLED)
    target_link_libraries(test-gpu-video PRIVATE ${FFMPEG_TARGETS} ${SDL2_TARGET} d3d11)
    add_custom_command(TARGET test-gpu-video POST_BUILD
        COMMAND ${CMAKE_COMMAND} -E copy_if_different
            $<TARGET_RUNTIME_DLLS:test-gpu-video> $<TARGET_FILE_DIR:test-gpu-video>
        COMMAND_EXPAND_LISTS)
endif()

# Use $<TARGET_RUNTIME_DLLS:airplay-windows> (CMake 3.21+) to copy ONLY
# the shared libraries the linker actually depends on transitively —
# pulls SDL2.dll, SDL2_ttf.dll, avcodec-*.dll, libplist-*.dll,
# gstreamer-1.0-0.dll, gstapp-*.dll, glib-2.0-0.dll, … without dragging
# along .pdb files, gst-launch-1.0.exe, ffmpeg.exe, the static .lib
# imports, headers, plugins, etc. — which were swelling the build dir
# past 900 MB with the previous copy_directory_if_different approach.
#
# GStreamer plugins (lib/gstreamer-1.0/*.dll) load dynamically at run
# time and are NOT in TARGET_RUNTIME_DLLS. We keep them where the
# system GStreamer install put them and let gst_init() find them via
# its registered plugin path — practically: as long as the user has
# GStreamer's bin/ on PATH the plugins resolve at startup.
if(WIN32)
    # Only deploy runtime modules; tools, weights and per-machine caches are separate.
    set(FACE_SWAP_RUNTIME_FILES
        face_swap_worker.py face_swap_gpu_worker.py face_swap_detection.py
        face_swap_progress.py face_swap_tensorrt.py face_swap_models.py face_swap_occlusion.py face_swap_parser.py face_swap_mask.py face_swap_detectors.py face_swap_landmarker.py face_swap_portrait.py
        download_face_swap_models.py prepare_face_swap_python.ps1 face_swap_models_manifest.json
        requirements-face-swap.txt requirements-face-swap-gpu.txt
        requirements-face-swap-directml.txt requirements-face-swap-cpu.txt requirements-face-swap-tensorrt.txt)
    add_custom_target(deploy-face-swap
        COMMAND ${CMAKE_COMMAND} -E make_directory "$<TARGET_FILE_DIR:airplay-windows>/face_swap/engine")
    foreach(runtime_file IN LISTS FACE_SWAP_RUNTIME_FILES)
        add_custom_command(TARGET deploy-face-swap POST_BUILD
            COMMAND ${CMAKE_COMMAND} -E copy_if_different
                "${CMAKE_SOURCE_DIR}/tools/${runtime_file}"
                "$<TARGET_FILE_DIR:airplay-windows>/face_swap/engine/${runtime_file}"
            VERBATIM)
    endforeach()
    add_custom_command(TARGET deploy-face-swap POST_BUILD
        COMMAND ${CMAKE_COMMAND} -E copy_if_different
            "${CMAKE_SOURCE_DIR}/docs/FACE_SWAP_DISTRIBUTION.md"
            "$<TARGET_FILE_DIR:airplay-windows>/face_swap/README.md"
        VERBATIM)
    add_dependencies(airplay-windows deploy-face-swap)
    add_custom_command(TARGET airplay-windows POST_BUILD
        COMMAND ${CMAKE_COMMAND} -E copy_if_different
            $<TARGET_RUNTIME_DLLS:airplay-windows>
            $<TARGET_FILE_DIR:airplay-windows>
        COMMAND_EXPAND_LISTS
        COMMENT "Deploying linked runtime DLLs next to airplay-windows.exe"
        VERBATIM)
endif()

# ---- Avahi (optional, Linux only — dev-mode mDNS) ----------------------------
# Lets the receiver auto-appear on iOS when launched from a Linux host for
# hacking / testing. Windows uses the native dnsapi above.
if(NOT WIN32 AND PkgConfig_FOUND)
    pkg_check_modules(AVAHI_CLIENT IMPORTED_TARGET avahi-client)
    if(AVAHI_CLIENT_FOUND)
        target_link_libraries(airplay-windows PRIVATE PkgConfig::AVAHI_CLIENT)
        target_compile_definitions(airplay-windows PRIVATE HAVE_AVAHI=1)
        message(STATUS "Avahi: linking via PkgConfig::AVAHI_CLIENT")
    else()
        message(STATUS "Avahi: not found — mDNS disabled on this Linux build "
                       "(apt install libavahi-client-dev)")
    endif()
endif()

# Focused regression tests for receiver disconnect and shutdown.
option(BUILD_NETWORK_TESTS "Build socket shutdown regression tests" OFF)
if(BUILD_NETWORK_TESTS)
    add_executable(test-hls tools/test_hls.cpp src/video/hls_player.cpp src/audio/audio_output.cpp
        src/airplay/hls_local_server.cpp src/airplay/hls_session.cpp src/airplay/fcup.cpp
        src/airplay/reverse_channel.cpp src/net/tcp_server.cpp src/net/socket.cpp src/log.cpp)
    target_include_directories(test-hls PRIVATE src ${FFMPEG_INCLUDE_DIRS_OK})
    target_link_libraries(test-hls PRIVATE ${FFMPEG_TARGETS} ${SDL2_TARGET} ${LIBPLIST_TARGET})
    target_compile_definitions(test-hls PRIVATE HAVE_LIBPLIST=1)
    if(WIN32)
        target_link_libraries(test-hls PRIVATE ws2_32 iphlpapi)
    endif()
    add_executable(test-firewall tools/test_firewall.cpp src/platform/firewall.cpp)
    target_include_directories(test-firewall PRIVATE src)
    if(WIN32)
        target_link_libraries(test-firewall PRIVATE shell32 ole32 oleaut32)
    endif()
    add_executable(test-settings tools/test_settings.cpp src/settings.cpp src/log.cpp)
    target_include_directories(test-settings PRIVATE src)
    add_executable(test-i18n tools/test_i18n.cpp)
    target_include_directories(test-i18n PRIVATE src)
    if(WIN32)
        target_link_libraries(test-settings PRIVATE shell32 ole32)
    endif()
    add_executable(test-cover-art tools/test_cover_art.cpp src/video/cover_art.cpp)
    target_include_directories(test-cover-art PRIVATE src ${FFMPEG_INCLUDE_DIRS_OK})
    target_link_libraries(test-cover-art PRIVATE ${FFMPEG_TARGETS})
    add_executable(test-audio-timing tools/test_audio_timing.cpp src/airplay/ntp_client.cpp
        src/audio/audio_receiver.cpp src/audio/aac_decoder.cpp src/audio/audio_output.cpp src/net/socket.cpp)
    target_include_directories(test-audio-timing PRIVATE src ${FFMPEG_INCLUDE_DIRS_OK})
    target_link_libraries(test-audio-timing PRIVATE ${FFMPEG_TARGETS} ${SDL2_TARGET} OpenSSL::Crypto)
    if(WIN32)
        target_link_libraries(test-audio-timing PRIVATE ws2_32 iphlpapi)
    endif()
    add_executable(test-shutdown tools/test_shutdown.cpp src/airplay/dacp_remote.cpp src/airplay/rtsp_parser.cpp src/net/tcp_server.cpp
        src/net/socket.cpp src/mdns/mdns_service.cpp src/log.cpp)
    target_include_directories(test-shutdown PRIVATE src)
    if(WIN32)
        target_link_libraries(test-shutdown PRIVATE ws2_32 iphlpapi dnsapi)
    else()
        find_package(Threads REQUIRED)
        target_link_libraries(test-shutdown PRIVATE Threads::Threads)
    endif()
    enable_testing()
    add_test(NAME hls COMMAND test-hls)
    set_tests_properties(hls PROPERTIES TIMEOUT 20)
    add_test(NAME firewall COMMAND test-firewall)
    add_test(NAME settings COMMAND test-settings)
    add_test(NAME i18n COMMAND test-i18n)
    if(WIN32)
        add_executable(test-python-setup tools/test_python_setup.cpp src/video/face_swap_process.cpp)
        target_include_directories(test-python-setup PRIVATE src)
        target_link_libraries(test-python-setup PRIVATE dxgi)
        add_test(NAME python-setup COMMAND test-python-setup)
        set_tests_properties(python-setup PROPERTIES TIMEOUT 30)
    endif()
    add_test(NAME socket-shutdown COMMAND test-shutdown)
    add_test(NAME audio-timing COMMAND test-audio-timing)
    add_test(NAME cover-art COMMAND test-cover-art)
    set_tests_properties(audio-timing PROPERTIES TIMEOUT 20)
    set_tests_properties(socket-shutdown PROPERTIES TIMEOUT 25)
endif()
