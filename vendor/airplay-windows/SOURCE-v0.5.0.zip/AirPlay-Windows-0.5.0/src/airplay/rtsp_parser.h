#pragma once
#include "net/socket.h"
#include <memory>

#include <cstddef>
#include <string>
#include <unordered_map>
#include <vector>

namespace ap::airplay {

// AirPlay uses an RTSP-like framing: request line, headers, optional body.
// Both HTTP/1.1 and RTSP/1.0 request lines are seen in the wild — we accept
// both. Requests use CRLF line endings; Content-Length drives body size.
struct Request {
    std::string method;             // "GET", "POST", "SETUP", "RECORD", ...
    std::string uri;                // "/info", "/pair-setup", "rtsp://.../stream", ...
    std::string version;            // "HTTP/1.1" or "RTSP/1.0"
    std::unordered_map<std::string, std::string> headers;  // lowercase keys
    std::vector<unsigned char> body;

    std::string header(const std::string& key) const;  // "" if missing
    std::size_t content_length() const;
};

struct Response {
    int status_code = 200;
    std::string status_text = "OK";
    std::string version = "RTSP/1.0";
    std::unordered_map<std::string, std::string> headers;
    std::vector<unsigned char> body;

    // When true, the server should not send this response on the wire.
    // Used to swallow responses iOS sends back to our FCUP Requests on
    // the reverse channel (which our request reader mis-parses as new
    // requests because they come on the same socket).
    bool silent = false;

    void set_header(std::string key, std::string value);
    std::string serialize() const;
};

// Blocking read of one full request from `fd`. Returns false on disconnect
// or protocol error. On success, `out` is fully populated and the body has
// exactly Content-Length bytes (0 if no header).
class RequestReader {
public:
    explicit RequestReader(std::shared_ptr<std::atomic<bool>> cancelled = {})
        : cancelled_(std::move(cancelled)) {}
    bool read(socket_t fd, Request& out);

private:
    std::shared_ptr<std::atomic<bool>> cancelled_;
    std::string buffer_;   // accumulated bytes across recv calls
    bool fill(socket_t fd, std::size_t need);
    bool read_headers(socket_t fd, Request& out, std::size_t& body_offset);
};

} // namespace ap::airplay
