#include "net/tcp_server.h"
#include "log.h"

#include <cstring>

namespace ap::net {

TcpServer::~TcpServer() {
    stop();
}

bool TcpServer::start(uint16_t port, Handler handler) {
    if (running_) return false;
    handler_ = std::move(handler);

    // Dual-stack listener: an IPv6 socket with IPV6_V6ONLY=0 accepts
    // both v4 and v6 clients (v4 peers arrive as ::ffff:A.B.C.D).
    // iOS 14+ sometimes reaches receivers over link-local IPv6 first,
    // and an IPv4-only listener dropped those connections silently.
    listener_ = ::socket(AF_INET6, SOCK_STREAM, IPPROTO_TCP);
    if (listener_ == INVALID_SOCK) {
        LOG_WARN << "socket(AF_INET6) failed — falling back to IPv4-only: "
                 << last_error_string();
        listener_ = ::socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (listener_ == INVALID_SOCK) {
            LOG_ERROR << "socket() failed: " << last_error_string();
            return false;
        }
    }

    int on = 1;
    ::setsockopt(listener_, SOL_SOCKET, SO_REUSEADDR,
                 reinterpret_cast<const char*>(&on), sizeof(on));

    // Disable IPV6_V6ONLY so the socket accepts v4 too. On Windows this
    // defaults to ON, on Linux it varies; set it explicitly either way.
    int v6only = 0;
    ::setsockopt(listener_, IPPROTO_IPV6, IPV6_V6ONLY,
                 reinterpret_cast<const char*>(&v6only), sizeof(v6only));

    sockaddr_in6 addr6{};
    addr6.sin6_family = AF_INET6;
    addr6.sin6_addr   = in6addr_any;
    addr6.sin6_port   = htons(port);

    if (::bind(listener_, reinterpret_cast<sockaddr*>(&addr6), sizeof(addr6)) != 0) {
        LOG_ERROR << "bind([::]:" << port << ") failed: " << last_error_string();
        close_socket(listener_);
        listener_ = INVALID_SOCK;
        return false;
    }

    if (::listen(listener_, 8) != 0) {
        LOG_ERROR << "listen() failed: " << last_error_string();
        close_socket(listener_);
        listener_ = INVALID_SOCK;
        return false;
    }

    sockaddr_storage bound{};
#if defined(_WIN32)
    int bound_len = sizeof(bound);
#else
    socklen_t bound_len = sizeof(bound);
#endif
    if (::getsockname(listener_, reinterpret_cast<sockaddr*>(&bound), &bound_len) != 0) {
        close_socket(listener_);
        listener_ = INVALID_SOCK;
        return false;
    }
    port_ = bound.ss_family == AF_INET6
        ? ntohs(reinterpret_cast<sockaddr_in6*>(&bound)->sin6_port)
        : ntohs(reinterpret_cast<sockaddr_in*>(&bound)->sin_port);
    running_ = true;
    accept_thread_ = std::thread(&TcpServer::accept_loop, this);
    LOG_INFO << "TCP server listening on [::]:" << port_
             << " (IPv4+IPv6)";
    return true;
}

void TcpServer::stop() {
    if (!running_.exchange(false)) return;

    // Closing the listener unblocks accept().
    close_socket(listener_);

    if (accept_thread_.joinable()) accept_thread_.join();
    listener_ = INVALID_SOCK;
    close_all_clients();
    for (auto& worker : workers_)
        if (worker.thread.joinable()) worker.thread.join();
    workers_.clear();
    port_ = 0;
}

void TcpServer::accept_loop() {
    while (running_) {
        sockaddr_storage peer{};
#if defined(_WIN32)
        int len = sizeof(peer);
#else
        socklen_t len = sizeof(peer);
#endif
        socket_t fd = ::accept(listener_, reinterpret_cast<sockaddr*>(&peer), &len);
        if (fd == INVALID_SOCK) {
            if (running_) {
                LOG_WARN << "accept() failed: " << last_error_string();
            }
            return;
        }

        // Format the peer as a human-readable "ip:port". For v4-mapped
        // v6 addresses (::ffff:A.B.C.D), strip the prefix so iOS clients
        // connecting over v4 still show up as plain dotted-quad. For
        // real IPv6 peers bracket the address — "[2a0f:d00::1]:49152" —
        // so downstream parsers (server.cpp, logs) can strip the port
        // without guessing which colon belongs to which side.
        char ip[INET6_ADDRSTRLEN] = {0};
        uint16_t peer_port = 0;
        bool peer_is_v6 = false;
        if (peer.ss_family == AF_INET6) {
            auto* in6 = reinterpret_cast<sockaddr_in6*>(&peer);
            if (IN6_IS_ADDR_V4MAPPED(&in6->sin6_addr)) {
                const uint32_t v4 = reinterpret_cast<uint32_t*>(&in6->sin6_addr)[3];
                in_addr a{}; a.s_addr = v4;
                inet_ntop(AF_INET, &a, ip, sizeof(ip));
            } else {
                inet_ntop(AF_INET6, &in6->sin6_addr, ip, sizeof(ip));
                peer_is_v6 = true;
            }
            peer_port = ntohs(in6->sin6_port);
        } else if (peer.ss_family == AF_INET) {
            auto* in4 = reinterpret_cast<sockaddr_in*>(&peer);
            inet_ntop(AF_INET, &in4->sin_addr, ip, sizeof(ip));
            peer_port = ntohs(in4->sin_port);
        }

#if defined(_WIN32)
        DWORD send_timeout = 2000;
#else
        timeval send_timeout{2, 0};
#endif
        ::setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO,
            reinterpret_cast<const char*>(&send_timeout), sizeof(send_timeout));
        ClientSocket client;
        client.fd   = fd;
        client.peer = peer_is_v6
            ? "[" + std::string(ip) + "]:" + std::to_string(peer_port)
            : std::string(ip) + ":" + std::to_string(peer_port);

        LOG_INFO << "accepted " << client.peer;
        const socket_t track_fd = client.fd;
        {
            std::lock_guard<std::mutex> lock(clients_mtx_);
            if (!running_ || disconnecting_) {
                close_socket(track_fd);
                continue;
            }
            active_clients_.emplace(track_fd, client.cancelled);
        }
        // Only the accept thread touches this vector until stop() joins it.
        // Reap completed workers as connections arrive, instead of retaining
        // one native thread handle and its bookkeeping per connection forever.
        for (auto it = workers_.begin(); it != workers_.end();) {
            if (it->finished->load(std::memory_order_acquire)) {
                it->thread.join();
                it = workers_.erase(it);
            } else {
                ++it;
            }
        }
        auto finished = std::make_shared<std::atomic<bool>>(false);
        workers_.push_back(Worker{std::thread([this, h = handler_, c = std::move(client),
                               track_fd, finished]() mutable {
            h(std::move(c));
            {
                std::lock_guard<std::mutex> lock(clients_mtx_);
                close_socket(track_fd);
                LOG_INFO << "control socket closed fd=" << track_fd;
                active_clients_.erase(track_fd);
                clients_cv_.notify_all();
            }
            finished->store(true, std::memory_order_release);
        }), finished});
    }
}

void TcpServer::close_all_clients(const std::function<void()>& on_drained) {
    std::unique_lock<std::mutex> lock(clients_mtx_);
    disconnecting_ = true;
    for (const auto& [fd, cancelled] : active_clients_) {
        cancelled->store(true);
#if defined(_WIN32)
        ::shutdown(fd, SD_BOTH);
#else
        ::shutdown(fd, SHUT_RDWR);
#endif
    }
    LOG_INFO << "TCP server: shutdown " << active_clients_.size()
             << " active client(s) on user request";
    // Workers erase entries only after the handler has stopped all media.
    clients_cv_.wait(lock, [this] { return active_clients_.empty(); });
    if (on_drained) on_drained();
    disconnecting_ = false;
}

} // namespace ap::net
